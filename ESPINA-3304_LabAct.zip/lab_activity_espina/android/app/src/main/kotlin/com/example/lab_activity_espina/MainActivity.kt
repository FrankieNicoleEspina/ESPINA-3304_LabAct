package com.example.lab_activity_espina

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
