import 'package:flutter/material.dart';
void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
       debugShowCheckedModeBanner: false,
      title: 'Top Bar Navigation',
      home: DefaultTabController(
        length: 5,
        child: Scaffold(
          appBar: AppBar(
            title: Text('My Profile'),
            bottom: TabBar(
              tabs: [
                Tab(icon: Icon(Icons.people), text: 'Personal Information'),
                Tab(icon: Icon(Icons.school_outlined),text: 'Educational Background'),
                Tab(icon: Icon(Icons.star), text: 'Skills'),
                Tab(icon: Icon(Icons.interests), text: 'Interests'),
                Tab(icon: Icon(Icons.contact_emergency),text: 'Contact Details'),
              ],
            ),
          ),
          body: TabBarView(
            children: [
              // Personal Information tab
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircleAvatar(
                      radius: 80,
                      backgroundImage: AssetImage('assets/unnamed.jpg'),
                    ),
                    SizedBox(height: 16),
                    Text('Frankie Nicole Espina',style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
                    Text('21', style: TextStyle(fontSize: 20)),
                    Text('November 21, 2002',style: TextStyle(fontSize: 20)),
                    Text('Bachelor of Science Information Technology',style: TextStyle(fontSize: 20)),
                    Text('Major in Bussiness Analytics',style: TextStyle(fontSize: 20)),
                     SizedBox(height: 16),
                    Icon(Icons.pets, size: 20), 
                   SizedBox(width: 8),
                   Text('I LOVE CATS',style: TextStyle(fontSize: 20)),
                  ],
                ),
              ),
             EducationalBackground(),
             Skills(),
             Interests(),
             ContactDetails(),


            ]   
          ),
        ),
      ),
    );
  }
}

class EducationalBackground extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text('Educational Background', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)), 
                   SizedBox(width: 8),
          SizedBox(height: 16),
          Text('Tertiary', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          Text('Batangas State University Alangilan, Batangas', style: TextStyle(fontSize: 18)),
          Text('BS Information Technology ', style: TextStyle(fontSize: 18)),
                    Text('2021-Present ', style: TextStyle(fontSize: 18)),
          SizedBox(height: 10),
          Text('Secondary', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          Text('STI College Batangas', style: TextStyle(fontSize: 18)),
          Text('Kumintang Ibaba, Batangas City', style: TextStyle(fontSize: 18)),
          Text('TVL- Information and Communication Technology', style: TextStyle(fontSize: 18)),
          Text('2019-2021', style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
          Text('Sta. Rita National High School', style: TextStyle(fontSize: 18)),
          Text('Sta. Rita Karsada, Batangas City', style: TextStyle(fontSize: 18)),
          Text('2015-2019', style: TextStyle(fontSize: 18)),
          SizedBox(height: 10),
          Text('Primary', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          Text('Calicanto Elementary School', style: TextStyle(fontSize: 18)),
          Text('Kumintang Ibaba, Batangas City', style: TextStyle(fontSize: 18)),
          Text('Calicanto, Batangas City', style: TextStyle(fontSize: 18)),
          Text('2009-2015', style: TextStyle(fontSize: 18)),
        ],
      ),
    );
  }
}

class Skills extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
         SizedBox(height: 10),
          Text('Technical Skills', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          Text('Programming Languages: Python, C++, C#', style: TextStyle(fontSize: 18)),
          Text('Web Development: HTML, CSS, JavaScript', style: TextStyle(fontSize: 18)),
          Text('Flutter, Android, iOS', style: TextStyle(fontSize: 18)),
          Text('MySQL, PostgreSQL', style: TextStyle(fontSize: 18)),
          Text('Data Science: Data Visualization, Data processing', style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
          Text('Non-Technical Skills', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          Text('Team Management, Project Management', style: TextStyle(fontSize: 18)),
          Text('Decision Making', style: TextStyle(fontSize: 18)),
          Text('Time Management Prioritization', style: TextStyle(fontSize: 18)),
        ],
      ),
    );
  }
}
class Interests extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text('Interests', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          SizedBox(height: 16),
          Text('Personal Growth', style: TextStyle(fontSize: 18)),
          SizedBox(height: 8),
          Text('Gaming', style: TextStyle(fontSize: 18)),
          SizedBox(height: 8),
          Text('Music', style: TextStyle(fontSize: 18)),
        ],
      ),
    );
  }
}
class ContactDetails extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text('Contact Details', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Icon(Icons.phone_callback, size: 18), // add an icon
              SizedBox(width: 8), // add some space between the icon and the text
              Text('Phone: 09363903119', style: TextStyle(fontSize: 18)),
            ],
          ),
          SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Icon(Icons.email, size: 18), // add an icon
              SizedBox(width: 8), // add some space between the icon and the text
              Text('Email: 21-03839@g.batstate-u.edu.ph', style: TextStyle(fontSize: 18)),
            ],
          ),
          SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Icon(Icons.location_on, size: 18), // add an icon
              SizedBox(width: 8), // add some space between the icon and the text
              Text('Address: Purok 1, Calicanto, Batangas City', style: TextStyle(fontSize: 18)),
              
            ],
          ),
           SizedBox(height: 8),
          Row(
             mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Icon(Icons.facebook, size: 18), // add an icon
              SizedBox(width: 8), // add some space between the icon and the text
              Text('https://www.facebook.com/espina1321?mibextid=ZbWKwL',style: TextStyle(color: Colors.blue,decoration: TextDecoration.underline,
          ),
        ),
            ],
          ),
        ],
      ),
    );
  }
}